'use client'
import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'

export default function CreateCapsuleForm({ plan }: { plan: string }) {
  const router  = useRouter()
  const fileRef = useRef<HTMLInputElement>(null)
  const [step, setStep]       = useState(1)
  const [loading, setLoading] = useState(false)
  const [error, setError]     = useState('')
  const [uploading, setUploading] = useState(false)

  const [form, setForm] = useState({
    title:           '',
    message:         '',
    recipient_name:  '',
    recipient_email: '',
    deliver_at:      '',
    media_url:       '',
    media_type:      '',
  })

  function set(k: string) {
    return (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      setForm(f => ({ ...f, [k]: e.target.value }))
  }

  const canUploadMedia = plan !== 'free'

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true); setError('')
    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ contentType: file.type }),
      })
      const { uploadUrl, publicUrl } = await res.json()
      if (!uploadUrl) throw new Error('Upload failed')
      await fetch(uploadUrl, { method: 'PUT', body: file, headers: { 'Content-Type': file.type } })
      const mediaType = file.type.startsWith('image/') ? 'image' : file.type.startsWith('video/') ? 'video' : 'audio'
      setForm(f => ({ ...f, media_url: publicUrl, media_type: mediaType }))
    } catch {
      setError('File upload failed. Please try again.')
    }
    setUploading(false)
  }

  async function handleSubmit() {
    setLoading(true); setError('')
    const res = await fetch('/api/capsules', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    const data = await res.json()
    setLoading(false)
    if (!res.ok) { setError(data.error); return }
    router.push('/dashboard?created=1')
  }

  // Min date = tomorrow
  const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate() + 1)
  const minDate = tomorrow.toISOString().split('T')[0]

  return (
    <div className="space-y-6">
      {/* Step indicator */}
      <div className="flex items-center gap-2 mb-8">
        {[1, 2, 3].map(s => (
          <div key={s} className="flex items-center gap-2">
            <div
              className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-mono font-medium transition-all duration-300"
              style={{
                background: s <= step ? 'linear-gradient(135deg,#d48c28,#b06f1e)' : '#f0e6d0',
                color: s <= step ? '#fffdf5' : '#b0926a',
              }}
            >{s}</div>
            <span className="font-body text-xs text-ink-400 hidden sm:block">
              {s === 1 ? 'Message' : s === 2 ? 'Recipient' : 'Schedule'}
            </span>
            {s < 3 && <div className="w-8 h-px" style={{ background: s < step ? '#d48c28' : '#e8d5b0' }} />}
          </div>
        ))}
      </div>

      {error && (
        <div className="px-4 py-3 rounded text-sm font-body text-red-700" style={{ background: '#fef2f2', border: '1px solid #fecaca' }}>
          {error}
        </div>
      )}

      {/* Step 1 — Message */}
      {step === 1 && (
        <div className="letter-card p-7 space-y-5" style={{ animation: 'fadeUp 0.4s ease forwards' }}>
          <div>
            <label className="block font-serif text-base text-ink-800 mb-1">Title <span className="text-red-400">*</span></label>
            <p className="font-body text-xs text-ink-400 mb-2">A short title for this capsule (only you see this)</p>
            <input type="text" value={form.title} onChange={set('title')}
              className="input-parchment" placeholder="e.g. For Aanya on her 18th birthday" required maxLength={100} />
          </div>

          <div>
            <label className="block font-serif text-base text-ink-800 mb-1">Your message <span className="text-red-400">*</span></label>
            <p className="font-body text-xs text-ink-400 mb-2">Write from the heart. This will be delivered exactly as you write it.</p>
            <textarea
              value={form.message}
              onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
              className="input-parchment"
              rows={8}
              placeholder="Dear Aanya,&#10;&#10;By the time you read this..."
              required
              style={{ resize: 'vertical', fontFamily: 'Lora, serif', fontSize: '15px', lineHeight: '1.8' }}
            />
            <p className="font-mono text-xs text-ink-400 mt-1 text-right">{form.message.length} chars</p>
          </div>

          {/* Media upload */}
          <div>
            <label className="block font-serif text-base text-ink-800 mb-1">
              Attach media <span className="font-body text-xs text-ink-400 font-normal">(optional)</span>
            </label>
            {!canUploadMedia ? (
              <div
                className="px-4 py-3 rounded text-sm font-body flex items-center justify-between"
                style={{ background: '#fdf0d0', border: '1px solid #e8d5b0' }}
              >
                <span className="text-ink-600">Photo/video/audio requires a paid plan</span>
                <a href="/pricing" className="text-ink-800 underline text-xs">Upgrade →</a>
              </div>
            ) : (
              <div>
                <input ref={fileRef} type="file" accept="image/*,video/*,audio/*" className="hidden" onChange={handleFileUpload} />
                {form.media_url ? (
                  <div className="flex items-center gap-3 px-4 py-3 rounded" style={{ background: '#e8f5e9', border: '1px solid #c8e6c9' }}>
                    <span>✅</span>
                    <span className="font-body text-sm text-green-800">File attached</span>
                    <button onClick={() => setForm(f => ({ ...f, media_url: '', media_type: '' }))}
                      className="ml-auto text-xs text-red-600 underline">Remove</button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    disabled={uploading}
                    className="btn-secondary w-full flex items-center justify-center gap-2"
                  >
                    {uploading ? '⏳ Uploading...' : '📎 Attach photo, video or audio'}
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={() => { if (!form.title || !form.message) { setError('Please fill in title and message.'); return } setError(''); setStep(2) }}
              className="btn-primary"
            >
              Next: Choose recipient →
            </button>
          </div>
        </div>
      )}

      {/* Step 2 — Recipient */}
      {step === 2 && (
        <div className="letter-card p-7 space-y-5" style={{ animation: 'fadeUp 0.4s ease forwards' }}>
          <div>
            <label className="block font-serif text-base text-ink-800 mb-1">Recipient's name <span className="text-red-400">*</span></label>
            <input type="text" value={form.recipient_name} onChange={set('recipient_name')}
              className="input-parchment" placeholder="Aanya" required />
          </div>
          <div>
            <label className="block font-serif text-base text-ink-800 mb-1">Recipient's email <span className="text-red-400">*</span></label>
            <p className="font-body text-xs text-ink-400 mb-2">This is where the capsule will be delivered. Double-check it!</p>
            <input type="email" value={form.recipient_email} onChange={set('recipient_email')}
              className="input-parchment" placeholder="aanya@example.com" required />
          </div>
          <div className="flex justify-between pt-2">
            <button onClick={() => setStep(1)} className="btn-secondary">← Back</button>
            <button
              onClick={() => { if (!form.recipient_name || !form.recipient_email) { setError('Please fill in recipient details.'); return } setError(''); setStep(3) }}
              className="btn-primary"
            >
              Next: Set delivery date →
            </button>
          </div>
        </div>
      )}

      {/* Step 3 — Schedule */}
      {step === 3 && (
        <div className="letter-card p-7 space-y-5" style={{ animation: 'fadeUp 0.4s ease forwards' }}>
          <div>
            <label className="block font-serif text-base text-ink-800 mb-1">Delivery date <span className="text-red-400">*</span></label>
            <p className="font-body text-xs text-ink-400 mb-2">Choose any future date — near or decades away.</p>
            <input type="date" value={form.deliver_at} onChange={set('deliver_at')}
              min={minDate} className="input-parchment" required />
          </div>

          {/* Summary */}
          {form.deliver_at && (
            <div className="rounded p-4 space-y-2" style={{ background: '#fdf0d0', border: '1px solid #e8d5b0' }}>
              <p className="font-serif text-sm text-ink-700 font-semibold">📋 Capsule summary</p>
              <p className="font-body text-sm text-ink-600"><strong>Title:</strong> {form.title}</p>
              <p className="font-body text-sm text-ink-600"><strong>To:</strong> {form.recipient_name} ({form.recipient_email})</p>
              <p className="font-body text-sm text-ink-600"><strong>Delivers:</strong> {new Date(form.deliver_at).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
              {form.media_type && <p className="font-body text-sm text-ink-600"><strong>Media:</strong> {form.media_type} attached</p>}
            </div>
          )}

          <div className="flex justify-between pt-2">
            <button onClick={() => setStep(2)} className="btn-secondary">← Back</button>
            <button
              onClick={() => { if (!form.deliver_at) { setError('Please choose a delivery date.'); return } handleSubmit() }}
              disabled={loading}
              className="btn-primary"
              style={{ opacity: loading ? 0.7 : 1 }}
            >
              {loading ? '⏳ Saving...' : '💌 Save Capsule'}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
