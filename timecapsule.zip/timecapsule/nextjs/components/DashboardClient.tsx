'use client'
import { useState } from 'react'
import Link from 'next/link'
import { format, formatDistanceToNow, isPast } from 'date-fns'

interface Capsule {
  id: string; title: string; recipient_name: string; recipient_email: string
  deliver_at: string; status: string; created_at: string; media_type: string | null
}

const MEDIA_ICON: Record<string, string> = {
  image: '🖼️', video: '🎬', audio: '🎙️',
}

const STATUS_STYLES: Record<string, { bg: string; color: string; label: string }> = {
  pending: { bg: '#fdf0d0', color: '#8d6238', label: 'Scheduled' },
  sent:    { bg: '#e8f5e9', color: '#2e7d32', label: 'Delivered' },
  failed:  { bg: '#fef2f2', color: '#c62828', label: 'Failed'    },
}

export default function DashboardClient({ capsules: initial, plan }: { capsules: Capsule[]; plan: string }) {
  const [capsules, setCapsules] = useState(initial)
  const [deleting, setDeleting] = useState<string | null>(null)

  async function handleDelete(id: string) {
    if (!confirm('Delete this capsule? This cannot be undone.')) return
    setDeleting(id)
    const res = await fetch(`/api/capsules/${id}`, { method: 'DELETE' })
    if (res.ok) setCapsules(c => c.filter(x => x.id !== id))
    else alert('Failed to delete capsule.')
    setDeleting(null)
  }

  if (capsules.length === 0) {
    return (
      <div className="letter-card p-16 text-center">
        <div className="text-5xl mb-4">💌</div>
        <h3 className="font-serif text-xl text-ink-700 mb-2">No capsules yet</h3>
        <p className="font-body text-sm text-ink-500 mb-6">Write your first message — it only takes a minute.</p>
        <Link href="/capsule/create" className="btn-primary">Write a message →</Link>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {capsules.map((c, i) => {
        const st = STATUS_STYLES[c.status] ?? STATUS_STYLES.pending
        const deliverDate = new Date(c.deliver_at)
        const timeLabel   = isPast(deliverDate)
          ? `Delivered ${formatDistanceToNow(deliverDate, { addSuffix: true })}`
          : `Delivers ${formatDistanceToNow(deliverDate, { addSuffix: true })}`

        return (
          <div
            key={c.id}
            className="letter-card p-5 flex items-center gap-4"
            style={{ opacity: 0, animation: `fadeUp 0.5s ease ${i * 0.06}s forwards` }}
          >
            <div className="text-2xl flex-shrink-0">{c.media_type ? MEDIA_ICON[c.media_type] ?? '📄' : '📝'}</div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <h3 className="font-serif text-base text-ink-800 truncate">{c.title}</h3>
                <span
                  className="flex-shrink-0 text-xs font-body px-2 py-0.5 rounded-full"
                  style={{ background: st.bg, color: st.color }}
                >
                  {st.label}
                </span>
              </div>
              <p className="font-body text-sm text-ink-500">
                To <strong className="text-ink-700">{c.recipient_name}</strong> · {c.recipient_email}
              </p>
              <p className="font-mono text-xs text-ink-400 mt-1">
                📅 {format(deliverDate, 'MMMM d, yyyy')} &nbsp;·&nbsp; {timeLabel}
              </p>
            </div>

            {c.status === 'pending' && (
              <button
                onClick={() => handleDelete(c.id)}
                disabled={deleting === c.id}
                className="flex-shrink-0 text-xs font-body px-3 py-1.5 rounded text-red-600 border border-red-200 hover:bg-red-50 transition-colors"
                style={{ opacity: deleting === c.id ? 0.5 : 1 }}
              >
                {deleting === c.id ? '…' : 'Delete'}
              </button>
            )}
          </div>
        )
      })}

      {plan === 'free' && (
        <div
          className="mt-6 p-5 rounded-lg text-center"
          style={{ background: 'linear-gradient(135deg,#fdf0d0,#fdf6e3)', border: '1px dashed #d4bfa5' }}
        >
          <p className="font-body text-sm text-ink-600 mb-3">
            You&apos;re on the free plan · <strong>{capsules.length}/3</strong> capsules used
          </p>
          <Link href="/pricing" className="btn-primary text-sm py-2 px-6">Upgrade for more →</Link>
        </div>
      )}
    </div>
  )
}
