import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { query, queryOne, PLAN_LIMITS } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const capsules = await query(
    `SELECT id, title, recipient_name, recipient_email, deliver_at, status, created_at, media_type
     FROM capsules WHERE user_id = $1 ORDER BY deliver_at ASC`,
    [session.user.id]
  )
  return NextResponse.json(capsules)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const body = await req.json()
    const { title, message, recipient_name, recipient_email, deliver_at, media_url, media_type } = body

    if (!title || !message || !recipient_name || !recipient_email || !deliver_at)
      return NextResponse.json({ error: 'Missing required fields.' }, { status: 400 })

    if (new Date(deliver_at) <= new Date())
      return NextResponse.json({ error: 'Delivery date must be in the future.' }, { status: 400 })

    // Check plan limits
    const plan  = session.user.plan as keyof typeof PLAN_LIMITS
    const limit = PLAN_LIMITS[plan]?.capsules ?? 3
    const count = await queryOne<{ capsule_count: string }>(
      'SELECT capsule_count FROM user_capsule_counts WHERE user_id = $1',
      [session.user.id]
    )
    const current = parseInt(count?.capsule_count ?? '0')
    if (current >= limit)
      return NextResponse.json({ error: `You've reached the ${limit}-capsule limit on your ${plan} plan. Upgrade to add more.` }, { status: 403 })

    // Media only allowed on paid plans
    if (media_url && !PLAN_LIMITS[plan]?.media)
      return NextResponse.json({ error: 'Media uploads require a paid plan.' }, { status: 403 })

    const capsule = await queryOne<{ id: string }>(
      `INSERT INTO capsules (user_id, title, message, recipient_name, recipient_email, deliver_at, media_url, media_type)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id`,
      [session.user.id, title, message, recipient_name, recipient_email, deliver_at, media_url ?? null, media_type ?? null]
    )

    return NextResponse.json({ id: capsule?.id }, { status: 201 })
  } catch (err) {
    console.error('Create capsule error:', err)
    return NextResponse.json({ error: 'Something went wrong.' }, { status: 500 })
  }
}
