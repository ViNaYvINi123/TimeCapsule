import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { queryOne } from '@/lib/db'
import { deleteFile } from '@/lib/r2'

export async function DELETE(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const capsule = await queryOne<{ id: string; media_url: string | null; status: string }>(
    'SELECT id, media_url, status FROM capsules WHERE id = $1 AND user_id = $2',
    [params.id, session.user.id]
  )
  if (!capsule) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  if (capsule.status === 'sent') return NextResponse.json({ error: 'Cannot delete a sent capsule.' }, { status: 400 })

  // Delete media from R2 if exists
  if (capsule.media_url) {
    const key = capsule.media_url.split('/').pop()
    if (key) await deleteFile(key).catch(() => {})
  }

  await queryOne('DELETE FROM capsules WHERE id = $1', [params.id])
  return NextResponse.json({ success: true })
}
