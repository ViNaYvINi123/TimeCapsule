import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { queryOne } from '@/lib/db'
import Razorpay from 'razorpay'

const razorpay = new Razorpay({
  key_id:     process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
})

const PLAN_PRICES: Record<string, { amount: number; label: string }> = {
  plus: { amount: 19900, label: 'TimeCapsule Plus'  }, // ₹199
  pro:  { amount: 49900, label: 'TimeCapsule Pro'   }, // ₹499
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { plan } = await req.json()
  const price = PLAN_PRICES[plan]
  if (!price) return NextResponse.json({ error: 'Invalid plan.' }, { status: 400 })

  const order = await razorpay.orders.create({
    amount:   price.amount,
    currency: 'INR',
    receipt:  `tc_${Date.now()}`,
    notes:    { user_id: session.user.id, plan },
  })

  // Store pending payment
  await queryOne(
    `INSERT INTO payments (user_id, razorpay_order_id, amount, currency, plan)
     VALUES ($1, $2, $3, $4, $5)`,
    [session.user.id, order.id, price.amount, 'INR', plan]
  )

  return NextResponse.json({
    orderId:  order.id,
    amount:   price.amount,
    currency: 'INR',
    keyId:    process.env.RAZORPAY_KEY_ID,
    name:     price.label,
  })
}
