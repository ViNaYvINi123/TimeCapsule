import { NextRequest, NextResponse } from 'next/server'
import crypto from 'crypto'
import { queryOne } from '@/lib/db'

export async function POST(req: NextRequest) {
  const body      = await req.text()
  const signature = req.headers.get('x-razorpay-signature') ?? ''

  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET!)
    .update(body)
    .digest('hex')

  if (signature !== expected)
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })

  const event = JSON.parse(body)

  if (event.event === 'payment.captured') {
    const payment = event.payload.payment.entity
    const orderId = payment.order_id

    const row = await queryOne<{ user_id: string; plan: string }>(
      'SELECT user_id, plan FROM payments WHERE razorpay_order_id = $1',
      [orderId]
    )
    if (!row) return NextResponse.json({ error: 'Order not found' }, { status: 404 })

    await queryOne(
      `UPDATE payments SET status = 'paid', razorpay_payment_id = $1 WHERE razorpay_order_id = $2`,
      [payment.id, orderId]
    )
    await queryOne(
      `UPDATE users SET plan = $1, plan_expires_at = NOW() + INTERVAL '30 days', updated_at = NOW()
       WHERE id = $2`,
      [row.plan, row.user_id]
    )
  }

  return NextResponse.json({ status: 'ok' })
}
