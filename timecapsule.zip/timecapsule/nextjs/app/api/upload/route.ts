import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { getUploadUrl, getPublicUrl } from '@/lib/r2'
import { PLAN_LIMITS } from '@/lib/db'
import crypto from 'crypto'

const ALLOWED_TYPES: Record<string, string> = {
  'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp',
  'image/gif': 'gif', 'audio/mpeg': 'mp3', 'audio/webm': 'webm',
  'video/mp4': 'mp4', 'video/webm': 'webm',
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const plan = session.user.plan as keyof typeof PLAN_LIMITS
  if (!PLAN_LIMITS[plan]?.media)
    return NextResponse.json({ error: 'Media uploads require a paid plan.' }, { status: 403 })

  const { contentType } = await req.json()
  const ext = ALLOWED_TYPES[contentType]
  if (!ext) return NextResponse.json({ error: 'File type not allowed.' }, { status: 400 })

  const key       = `${session.user.id}/${crypto.randomUUID()}.${ext}`
  const uploadUrl = await getUploadUrl(key, contentType)
  const publicUrl = getPublicUrl(key)

  return NextResponse.json({ uploadUrl, publicUrl, key })
}
