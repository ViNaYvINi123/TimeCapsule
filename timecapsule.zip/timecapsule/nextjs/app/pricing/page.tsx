'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'

declare global { interface Window { Razorpay: new (opts: object) => { open(): void } } }

const PLANS = [
  {
    key: 'free', name: 'Free', price: '₹0', period: 'forever',
    color: '#f3f4f6', accent: '#6b7280',
    features: ['3 capsules', 'Text only', 'Email delivery', 'Forever free'],
    cta: 'Get started',
  },
  {
    key: 'plus', name: 'Plus', price: '₹199', period: '/month',
    color: '#fdf0d0', accent: '#b06f1e',
    features: ['20 capsules', 'Photos (up to 1 per capsule)', '3-min audio recording', 'Priority delivery'],
    cta: 'Upgrade to Plus',
    popular: true,
  },
  {
    key: 'pro', name: 'Pro', price: '₹499', period: '/month',
    color: '#3d2610', accent: '#fdf0d0',
    dark: true,
    features: ['100 capsules', 'Photos, video & audio', '15-min video messages', 'Early access to new features'],
    cta: 'Upgrade to Pro',
  },
]

export default function PricingPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState<string | null>(null)

  async function handleUpgrade(planKey: string) {
    if (!session) { router.push('/register'); return }
    if (planKey === 'free') return
    setLoading(planKey)

    try {
      const res  = await fetch('/api/payment/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan: planKey }),
      })
      const order = await res.json()

      // Load Razorpay script dynamically
      if (!window.Razorpay) {
        await new Promise<void>((resolve, reject) => {
          const s = document.createElement('script')
          s.src = 'https://checkout.razorpay.com/v1/checkout.js'
          s.onload = () => resolve(); s.onerror = () => reject()
          document.head.appendChild(s)
        })
      }

      const rzp = new window.Razorpay({
        key:         order.keyId,
        amount:      order.amount,
        currency:    order.currency,
        name:        'TimeCapsule',
        description: order.name,
        order_id:    order.orderId,
        prefill:     { email: session.user.email, name: session.user.name },
        theme:       { color: '#d48c28' },
        handler: () => {
          router.push('/dashboard?upgraded=1')
        },
      })
      rzp.open()
    } catch (e) {
      console.error(e)
      alert('Something went wrong. Please try again.')
    }
    setLoading(null)
  }

  return (
    <main className="min-h-screen">
      <nav className="border-b border-parchment-200 px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-xl">✉️</span>
            <span className="font-serif text-lg text-ink-800">TimeCapsule</span>
          </Link>
          {session ? (
            <Link href="/dashboard" className="btn-secondary text-sm py-2 px-5">Dashboard</Link>
          ) : (
            <Link href="/login" className="btn-secondary text-sm py-2 px-5">Sign in</Link>
          )}
        </div>
      </nav>

      <section className="max-w-5xl mx-auto px-6 py-16 text-center">
        <h1 className="font-serif text-5xl text-ink-800 mb-3">Simple, honest pricing</h1>
        <p className="font-body text-ink-500 mb-14 max-w-xl mx-auto">Start free. Upgrade only when you need more. No hidden fees, ever.</p>

        <div className="grid md:grid-cols-3 gap-6 items-start">
          {PLANS.map(plan => (
            <div
              key={plan.key}
              className="rounded-lg p-7 text-left relative"
              style={{
                background: plan.color,
                border: plan.popular ? '2px solid #d48c28' : '1px solid #e8d5b0',
                color: plan.dark ? '#fdf6e3' : '#3d2610',
              }}
            >
              {plan.popular && (
                <div
                  className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-xs font-body font-medium"
                  style={{ background: '#d48c28', color: '#fffdf5' }}
                >
                  Most popular
                </div>
              )}

              <div className="mb-4">
                <p className="font-body text-xs uppercase tracking-widest mb-1" style={{ color: plan.accent }}>{plan.name}</p>
                <div className="flex items-baseline gap-1">
                  <span className="font-serif text-4xl">{plan.price}</span>
                  <span className="font-body text-sm opacity-60">{plan.period}</span>
                </div>
              </div>

              <ul className="space-y-2 mb-7">
                {plan.features.map(f => (
                  <li key={f} className="font-body text-sm flex items-start gap-2">
                    <span style={{ color: plan.accent }}>✓</span> {f}
                  </li>
                ))}
              </ul>

              <button
                onClick={() => handleUpgrade(plan.key)}
                disabled={loading === plan.key || (session?.user.plan === plan.key)}
                className="w-full py-3 rounded font-body font-medium text-sm transition-all"
                style={{
                  background: plan.dark ? '#fdf0d0' : plan.popular ? 'linear-gradient(135deg,#d48c28,#b06f1e)' : '#fff',
                  color:  plan.dark ? '#3d2610' : plan.popular ? '#fffdf5' : '#5c3d22',
                  border: plan.popular || plan.dark ? 'none' : '1.5px solid #d4bfa5',
                  opacity: session?.user.plan === plan.key ? 0.6 : 1,
                  cursor: session?.user.plan === plan.key ? 'default' : 'pointer',
                }}
              >
                {session?.user.plan === plan.key
                  ? '✓ Current plan'
                  : loading === plan.key ? 'Loading...'
                  : plan.cta}
              </button>
            </div>
          ))}
        </div>

        <p className="font-body text-xs text-ink-400 mt-10">
          Payments powered by Razorpay · Secure · Supports UPI, cards, netbanking
        </p>
      </section>
    </main>
  )
}
