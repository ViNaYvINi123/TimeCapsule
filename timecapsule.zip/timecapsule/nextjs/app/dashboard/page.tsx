import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { query } from '@/lib/db'
import Link from 'next/link'
import DashboardClient from '@/components/DashboardClient'

interface Capsule {
  id: string; title: string; recipient_name: string; recipient_email: string
  deliver_at: string; status: string; created_at: string; media_type: string | null
}

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/login')

  const capsules = await query<Capsule>(
    `SELECT id, title, recipient_name, recipient_email, deliver_at, status, created_at, media_type
     FROM capsules WHERE user_id = $1 ORDER BY deliver_at ASC`,
    [session.user.id]
  )

  const counts = {
    total: capsules.length,
    pending: capsules.filter(c => c.status === 'pending').length,
    sent:    capsules.filter(c => c.status === 'sent').length,
  }

  return (
    <main className="min-h-screen">
      {/* Top nav */}
      <nav className="border-b border-parchment-200 px-6 py-4">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-xl">✉️</span>
            <span className="font-serif text-lg text-ink-800">TimeCapsule</span>
          </Link>
          <div className="flex items-center gap-4">
            <span
              className="text-xs font-mono px-2 py-1 rounded-full capitalize"
              style={{ background: session.user.plan === 'free' ? '#f3f4f6' : '#fdf0d0', color: session.user.plan === 'free' ? '#6b7280' : '#8d6238', border: '1px solid', borderColor: session.user.plan === 'free' ? '#e5e7eb' : '#e8d5b0' }}
            >
              {session.user.plan}
            </span>
            <span className="font-body text-sm text-ink-600">{session.user.name}</span>
            <Link href="/api/auth/signout" className="btn-secondary text-xs py-1.5 px-4">Sign out</Link>
          </div>
        </div>
      </nav>

      <div className="max-w-5xl mx-auto px-6 py-10">
        {/* Header row */}
        <div className="flex items-start justify-between mb-8">
          <div>
            <h1 className="font-serif text-3xl text-ink-800">Your Capsules</h1>
            <p className="font-body text-sm text-ink-500 mt-1">
              {counts.pending} scheduled · {counts.sent} delivered
            </p>
          </div>
          <Link href="/capsule/create" className="btn-primary flex items-center gap-2">
            <span>＋</span> New Capsule
          </Link>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {[
            { label: 'Total',     value: counts.total,   icon: '📬' },
            { label: 'Scheduled', value: counts.pending, icon: '⏳' },
            { label: 'Delivered', value: counts.sent,    icon: '✅' },
          ].map(s => (
            <div key={s.label} className="letter-card p-5 text-center">
              <div className="text-2xl mb-1">{s.icon}</div>
              <div className="font-serif text-3xl text-ink-800">{s.value}</div>
              <div className="font-body text-xs text-ink-400 mt-1">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Capsule list */}
        <DashboardClient capsules={capsules} plan={session.user.plan} />
      </div>
    </main>
  )
}
