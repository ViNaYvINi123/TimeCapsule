'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { signIn } from 'next-auth/react'

export default function RegisterPage() {
  const router = useRouter()
  const [form, setForm]     = useState({ name: '', email: '', password: '' })
  const [error, setError]   = useState('')
  const [loading, setLoading] = useState(false)

  function set(k: string) {
    return (e: React.ChangeEvent<HTMLInputElement>) => setForm(f => ({ ...f, [k]: e.target.value }))
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true); setError('')
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    const data = await res.json()
    if (!res.ok) { setError(data.error); setLoading(false); return }
    await signIn('credentials', { email: form.email, password: form.password, redirect: false })
    router.push('/dashboard')
  }

  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-4">
      <Link href="/" className="flex items-center gap-2 mb-8">
        <span className="text-2xl">✉️</span>
        <span className="font-serif text-xl text-ink-800">TimeCapsule</span>
      </Link>

      <div className="letter-card p-8 w-full max-w-md">
        <h1 className="font-serif text-2xl text-ink-800 mb-1">Create your account</h1>
        <p className="font-body text-sm text-ink-500 mb-6">Start with 3 free capsules</p>

        {error && (
          <div className="mb-4 px-4 py-3 rounded text-sm font-body text-red-700" style={{ background: '#fef2f2', border: '1px solid #fecaca' }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block font-body text-sm text-ink-700 mb-1">Your name</label>
            <input type="text" value={form.name} onChange={set('name')}
              className="input-parchment" placeholder="Ravi Kumar" required />
          </div>
          <div>
            <label className="block font-body text-sm text-ink-700 mb-1">Email</label>
            <input type="email" value={form.email} onChange={set('email')}
              className="input-parchment" placeholder="you@example.com" required />
          </div>
          <div>
            <label className="block font-body text-sm text-ink-700 mb-1">Password</label>
            <input type="password" value={form.password} onChange={set('password')}
              className="input-parchment" placeholder="Min. 8 characters" required minLength={8} />
          </div>
          <button type="submit" disabled={loading} className="btn-primary w-full text-center" style={{ opacity: loading ? 0.7 : 1 }}>
            {loading ? 'Creating account...' : 'Create Account →'}
          </button>
        </form>

        <div className="relative my-5">
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-parchment-200" /></div>
          <div className="relative flex justify-center"><span className="font-body text-xs text-ink-400 px-3" style={{ background: '#fffdf5' }}>or</span></div>
        </div>
        <button onClick={() => signIn('google', { callbackUrl: '/dashboard' })}
          className="btn-secondary w-full flex items-center justify-center gap-2">
          <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
          Continue with Google
        </button>

        <p className="font-body text-sm text-ink-500 text-center mt-5">
          Already have an account? <Link href="/login" className="text-ink-700 underline-animate">Sign in</Link>
        </p>
      </div>
    </main>
  )
}
