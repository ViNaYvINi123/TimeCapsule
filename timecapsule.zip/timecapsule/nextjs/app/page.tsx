import Link from 'next/link'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export default async function LandingPage() {
  const session = await getServerSession(authOptions)

  return (
    <main className="min-h-screen">
      {/* Nav */}
      <nav className="flex items-center justify-between px-6 py-5 max-w-6xl mx-auto">
        <div className="flex items-center gap-2">
          <span className="text-2xl">✉️</span>
          <span className="font-serif text-xl font-semibold text-ink-800">TimeCapsule</span>
        </div>
        <div className="flex items-center gap-4">
          <Link href="/pricing" className="text-ink-600 font-body text-sm underline-animate">Pricing</Link>
          {session ? (
            <Link href="/dashboard" className="btn-primary text-sm py-2 px-5">Dashboard →</Link>
          ) : (
            <>
              <Link href="/login" className="btn-secondary text-sm py-2 px-5">Sign In</Link>
              <Link href="/register" className="btn-primary text-sm py-2 px-5">Get Started</Link>
            </>
          )}
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-5xl mx-auto px-6 pt-20 pb-32 text-center">
        <div
          className="inline-block mb-6 px-4 py-1.5 rounded-full text-sm font-body"
          style={{ background: '#fdf0d0', color: '#8d6238', border: '1px solid #e8d5b0' }}
        >
          📬 Trusted by families across India
        </div>

        <h1
          className="font-serif text-5xl md:text-7xl leading-tight mb-6"
          style={{ color: '#3d2610', opacity: 0, animation: 'fadeUp 0.8s ease 0.1s forwards' }}
        >
          Words that wait
          <br />
          <em style={{ color: '#b06f1e' }}>for the right moment</em>
        </h1>

        <p
          className="font-body text-xl text-ink-500 max-w-2xl mx-auto mb-10 leading-relaxed"
          style={{ opacity: 0, animation: 'fadeUp 0.8s ease 0.25s forwards' }}
        >
          Write heartfelt messages today — to your children, partner, or future self.
          We deliver them exactly when you choose.
        </p>

        <div
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
          style={{ opacity: 0, animation: 'fadeUp 0.8s ease 0.4s forwards' }}
        >
          <Link href="/register" className="btn-primary text-base px-8 py-3">
            Write your first message — Free
          </Link>
          <Link href="#how-it-works" className="btn-secondary text-base px-8 py-3">
            See how it works
          </Link>
        </div>
      </section>

      {/* Demo card floating */}
      <section className="max-w-2xl mx-auto px-6 -mt-8 mb-24">
        <div
          className="letter-card p-8 text-left"
          style={{ opacity: 0, animation: 'fadeUp 0.9s ease 0.5s forwards' }}
        >
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="font-body text-xs text-ink-400 uppercase tracking-widest mb-1">To Aanya, on her 18th birthday</p>
              <h3 className="font-serif text-xl text-ink-800">My darling, where did the time go?</h3>
            </div>
            <div className="wax-seal text-white text-xs">💌</div>
          </div>
          <p className="font-body text-ink-600 leading-relaxed italic">
            "By the time you read this, you'll be standing at the edge of everything.
            I want you to know that I believed in you — every single day..."
          </p>
          <div
            className="mt-4 flex items-center gap-2 text-xs font-mono"
            style={{ color: '#c8a96e' }}
          >
            <span>📅</span>
            <span>Delivers: March 19, 2036</span>
            <span className="ml-auto px-2 py-0.5 rounded text-emerald-700" style={{ background: '#e8f5e9' }}>Scheduled</span>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="max-w-5xl mx-auto px-6 py-20">
        <h2 className="font-serif text-4xl text-center text-ink-800 mb-4">How it works</h2>
        <p className="text-center font-body text-ink-500 mb-16">Three simple steps. A lifetime of meaning.</p>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            { step: '01', icon: '✍️', title: 'Write your message', body: 'Compose a letter, add photos or voice notes. Write to anyone — your kids, yourself, a dear friend.' },
            { step: '02', icon: '📅', title: 'Choose a delivery date', body: 'Pick any date — a birthday, anniversary, graduation, or a rainy Tuesday 10 years from now.' },
            { step: '03', icon: '💌', title: 'We deliver it', body: 'On the chosen day, your message lands in their inbox — just as you wrote it. No fuss, no forgotten drafts.' },
          ].map(({ step, icon, title, body }) => (
            <div key={step} className="letter-card p-6">
              <div className="flex items-center gap-3 mb-4">
                <span className="font-mono text-xs text-parchment-600">{step}</span>
                <span className="text-2xl">{icon}</span>
              </div>
              <h3 className="font-serif text-lg text-ink-800 mb-2">{title}</h3>
              <p className="font-body text-sm text-ink-500 leading-relaxed">{body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing teaser */}
      <section className="max-w-4xl mx-auto px-6 py-16">
        <div
          className="rounded-lg p-10 text-center"
          style={{ background: 'linear-gradient(135deg, #fdf0d0, #fdf6e3)', border: '1px solid #e8d5b0' }}
        >
          <h2 className="font-serif text-3xl text-ink-800 mb-3">Free to start. Always.</h2>
          <p className="font-body text-ink-500 mb-6 max-w-lg mx-auto">
            3 capsules free. Upgrade for more messages, photos, and video — starting at just ₹199/month.
          </p>
          <Link href="/pricing" className="btn-primary">See all plans</Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-parchment-200 py-10 mt-8">
        <div className="max-w-5xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span>✉️</span>
            <span className="font-serif text-ink-700">TimeCapsule</span>
          </div>
          <p className="font-body text-xs text-ink-400">© {new Date().getFullYear()} TimeCapsule. Made with ♥ in India.</p>
          <div className="flex gap-4 text-xs text-ink-400 font-body">
            <Link href="/privacy" className="underline-animate">Privacy</Link>
            <Link href="/terms" className="underline-animate">Terms</Link>
          </div>
        </div>
      </footer>
    </main>
  )
}
