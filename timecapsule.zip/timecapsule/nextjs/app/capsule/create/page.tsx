import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { redirect } from 'next/navigation'
import CreateCapsuleForm from '@/components/CreateCapsuleForm'
import Link from 'next/link'

export default async function CreateCapsulePage() {
  const session = await getServerSession(authOptions)
  if (!session) redirect('/login')

  return (
    <main className="min-h-screen">
      <nav className="border-b border-parchment-200 px-6 py-4">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-xl">✉️</span>
            <span className="font-serif text-lg text-ink-800">TimeCapsule</span>
          </Link>
          <Link href="/dashboard" className="font-body text-sm text-ink-600 underline-animate">← Back to dashboard</Link>
        </div>
      </nav>

      <div className="max-w-3xl mx-auto px-6 py-12">
        <div className="mb-10">
          <h1 className="font-serif text-4xl text-ink-800 mb-2">Write a capsule</h1>
          <p className="font-body text-ink-500">Your words, preserved until the moment you choose.</p>
        </div>
        <CreateCapsuleForm plan={session.user.plan} />
      </div>
    </main>
  )
}
