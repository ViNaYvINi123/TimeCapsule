import type { Metadata } from 'next'
import './globals.css'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import SessionProvider from '@/components/SessionProvider'

export const metadata: Metadata = {
  title: 'TimeCapsule — Messages Across Time',
  description: 'Write letters today. Deliver them to the people you love — on any future date.',
  openGraph: {
    title: 'TimeCapsule',
    description: 'Write letters today. Deliver them to the people you love — on any future date.',
  },
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions)
  return (
    <html lang="en">
      <head />
      <body>
        <SessionProvider session={session}>
          <div className="relative z-10">
            {children}
          </div>
        </SessionProvider>
      </body>
    </html>
  )
}
