/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        serif: ['Playfair Display', 'Georgia', 'serif'],
        body: ['Lora', 'Georgia', 'serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      colors: {
        parchment: {
          50:  '#fdf9f0',
          100: '#fdf3dc',
          200: '#fae8bc',
          300: '#f5d790',
          400: '#eec063',
          500: '#e5a83e',
          600: '#d48c28',
          700: '#b06f1e',
          800: '#8d571f',
          900: '#73481e',
        },
        ink: {
          50:  '#f6f1eb',
          100: '#e8ddd0',
          200: '#d4bfa5',
          300: '#bc9a73',
          400: '#a87a4e',
          500: '#8d6238',
          600: '#724e2d',
          700: '#5c3d22',
          800: '#4a3019',
          900: '#3d2610',
        },
        cream: '#fdf6e3',
      },
      backgroundImage: {
        'paper': "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='400' height='400' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E\")",
      },
      boxShadow: {
        'letter': '0 4px 24px rgba(92, 61, 34, 0.15), 0 1px 4px rgba(92, 61, 34, 0.1)',
        'letter-lg': '0 8px 40px rgba(92, 61, 34, 0.2), 0 2px 8px rgba(92, 61, 34, 0.1)',
      },
      animation: {
        'fade-up': 'fadeUp 0.6s ease forwards',
        'fade-in': 'fadeIn 0.4s ease forwards',
        'float': 'float 6s ease-in-out infinite',
      },
      keyframes: {
        fadeUp: { '0%': { opacity: '0', transform: 'translateY(20px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        fadeIn: { '0%': { opacity: '0' }, '100%': { opacity: '1' } },
        float: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-10px)' } },
      },
    },
  },
  plugins: [],
}
