import { Pool } from 'pg'

declare global {
  // eslint-disable-next-line no-var
  var _pgPool: Pool | undefined
}

const pool =
  global._pgPool ??
  new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
  })

if (process.env.NODE_ENV !== 'production') global._pgPool = pool

export default pool

// Helper for single queries
export async function query<T = unknown>(
  text: string,
  params?: unknown[]
): Promise<T[]> {
  const res = await pool.query(text, params)
  return res.rows as T[]
}

export async function queryOne<T = unknown>(
  text: string,
  params?: unknown[]
): Promise<T | null> {
  const rows = await query<T>(text, params)
  return rows[0] ?? null
}

// Plan limits
export const PLAN_LIMITS = {
  free:  { capsules: 3,  media: false, videoMinutes: 0  },
  plus:  { capsules: 20, media: true,  videoMinutes: 3  },
  pro:   { capsules: 100,media: true,  videoMinutes: 15 },
}
