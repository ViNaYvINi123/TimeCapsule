import { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import GoogleProvider from 'next-auth/providers/google'
import bcrypt from 'bcryptjs'
import { queryOne } from './db'

interface DBUser {
  id: string
  name: string
  email: string
  password_hash: string | null
  plan: string
}

export const authOptions: NextAuthOptions = {
  secret: process.env.NEXTAUTH_SECRET,
  session: { strategy: 'jwt' },
  pages: {
    signIn: '/login',
    error: '/login',
  },
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
    CredentialsProvider({
      name: 'Email',
      credentials: {
        email:    { label: 'Email',    type: 'email' },
        password: { label: 'Password', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials.password) return null

        const user = await queryOne<DBUser>(
          'SELECT * FROM users WHERE email = $1',
          [credentials.email.toLowerCase()]
        )
        if (!user || !user.password_hash) return null

        const valid = await bcrypt.compare(credentials.password, user.password_hash)
        if (!valid) return null

        return { id: user.id, name: user.name, email: user.email, plan: user.plan }
      },
    }),
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      if (account?.provider === 'google') {
        // Upsert Google user
        await queryOne(
          `INSERT INTO users (email, name, google_id)
           VALUES ($1, $2, $3)
           ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name, google_id = EXCLUDED.google_id
           RETURNING id`,
          [user.email, user.name, profile?.sub]
        )
      }
      return true
    },
    async jwt({ token, user }) {
      if (user) {
        token.id   = user.id
        token.plan = (user as { plan?: string }).plan ?? 'free'
      }
      return token
    },
    async session({ session, token }) {
      if (token) {
        session.user.id   = token.id as string
        session.user.plan = token.plan as string
      }
      return session
    },
  },
}

// Extend session types
declare module 'next-auth' {
  interface Session {
    user: { id: string; name?: string | null; email?: string | null; plan: string }
  }
}
